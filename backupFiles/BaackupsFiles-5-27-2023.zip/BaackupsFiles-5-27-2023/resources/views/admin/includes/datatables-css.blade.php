<link href="{{ my_asset('plugins/table/datatable/datatables.css') }}" rel="stylesheet" type="text/css">
<link href="{{ my_asset('plugins/table/datatable/custom_dt_html5.css') }}" rel="stylesheet" type="text/css">
<link href="{{ my_asset('plugins/table/datatable/dt-global_style.css') }}" rel="stylesheet" type="text/css">
